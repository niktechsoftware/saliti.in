<?php $this->load->view('header.php')?>

	<div class="full-width main-home">
		<div class="container">
			<div class="row">
				<div class="col-md-12 col-lg-12 col-sm-12">
					<img src="<?php echo base_url();?>assets/images/vam.jpg" class="img-fullwidth img-responsive" style='height:280px; width:100%; border:1px solid lightgray;'><br/>
				</div>
				<div class="col-md-9">
					<div class="main-home-content">
						<h1>About Our Vision & Mission</h1>
						<p><strong>Our Vision & Mission:</strong><br/>
						We at I.T.I. SANIVTC will impart futuristic Technical Education and install high patterns of discipline through our dedicated staff who shall get global standards, making our students technologically superior and ethically strong who in turn shall improve the quality of life of the human race, to become a one of the best ITI of India, in rural sector in providing Job Oriented Industrial Training education with the facilities at par with urban ITI's embedded with human values. Our Missoin is to foster an intellectual and ethical environment in which both skills and spirit will thrives so as to impart Technical quality education, training and services and to SHAPE THE YOUTH CRAFTMEN who will strive to improve the quality of life. 
						<br />
						<p><strong>Our Objective:</strong><br/>
						The main Objective of our Institute is to provides cost effective and quality education at par with the best in the facilities. To provide semi-skilled/skilled workers to industry by systematic training to school leavers. To reduce unemployment among educated youth by equipping them with suitable skills for industrial employment. To develop sense of responsibility, discipline, commitment professional ethics and inculcate sprit of Enterpreneurship among students. To provide practical training of out side educational institute ,private industries and government organizations to help students gain insight into complexities real world of engineering.
						<br />
						&nbsp;<br />
						<p><strong>Our Aim & Achievements:</strong><br/>
						Mision content goes here
						<br />
						&nbsp;<br />
					</div>
				</div>
				<div class="col-md-3">
					<div class="sidebar">
						<div class="sidebar-service">
							<h3> Know More About </h3>
						</div>
						<div class="sidemenu">
							<ul>
								<li>
									<a href="about-us.html">
										About the Institute
									</a>
								</li>
								<li>
									<a href="introduction.html">Introduction of the Institute</a>
								</li>
								<li>
									<a href="scheme.html">Schemes Running in the Institute</a>
								</li>
								<li>
									<a href="admission.html">Admission Criteria</a>
								</li>
								<li>
									<a href="trades.html">Some other Notices </a>
								</li>
								<li>
									<a href="summary-ncvt.html">Some other notices and events</a>
								</li>
								<li>
									<a href="summary-scvt.html">Some other notices</a>
								</li>
								<li>
									<a href="court-case.html">Some More other notices</a>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>			
	</div>

<?php $this->load->view('footer.php')?>